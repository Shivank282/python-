def find_max(arr):
    return max(arr)

# Example usage:
numbers = [3, 1, 7, 5, 9, 2]
print(find_max(numbers))  # Output: 9
