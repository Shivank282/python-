def reverse_array(arr):
    return arr[::-1]

# Example usage:
numbers = [1, 2, 3, 4, 5]
print(reverse_array(numbers))  # Output: [5, 4, 3, 2, 1]
